package com.kafkademo.kafka;

import com.kafkademo.kafka.model.Student;
import com.kafkademo.kafka.service.Producer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Random;

@SpringBootApplication
public class KafkaProducerApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(KafkaProducerApplication.class, args);
	}

	@Autowired
	Producer producer;



	@Override
	public void run(String... args) throws Exception {

		for (int i=0;i<10;i++) {
			Random r = new Random();
			Student s = new Student();
			s.setId(String.valueOf(r.nextInt()));
			s.setName("Pravallika Madduluri "+r.nextInt());
			s.setSalary("1000000");
			producer.send(s);
		}
	}
}
