package com.kafkademo.kafka.service;

import com.kafkademo.kafka.model.Student;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class Producer<T>{

    private static final Logger LOG = LoggerFactory.getLogger(Producer.class);



    @Value("${spring.kafka.topic}")
    private String topic;



    @Autowired
    private KafkaTemplate<String, Student> kafkaTemplate;

    public void send(Student student){
       // if (student instanceof Student) {
          //  Student s = (Student) student;
            LOG.info("sending message='{}' to topic='{}'", student, topic);
            kafkaTemplate.send(topic, "123", student);
        }
    //}
}
