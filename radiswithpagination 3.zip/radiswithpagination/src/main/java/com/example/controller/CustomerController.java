package com.example.controller;

import com.example.Repository.CustomerRepository;
import com.example.model.Customer;
import com.example.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @PostMapping("/sendtokafka")
    public ResponseEntity<String> initializeCache() {
        customerService.sendCustomers();
        return ResponseEntity.ok("Cache initialized with Kafka and customers cached.");
    }


}


