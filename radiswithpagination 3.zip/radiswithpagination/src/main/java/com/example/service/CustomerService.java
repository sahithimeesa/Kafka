package com.example.service;

import com.example.Repository.CustomerRepository;
import com.example.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.time.ZonedDateTime;


@Service
public class CustomerService {
    private CustomerRepository customerRepository;

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    private static final String TOPIC = "customers-records";

    public void sendCustomers() {
        for (int i = 1; i <= 100; i++) {
            Customer customer = new Customer();
            customer.setId(i);
            customer.setName("Customer" + i);
            customer.setLocaldatetime(ZonedDateTime.now());
            kafkaTemplate.send("customers-records", customer);
            System.out.println("Sent message: " + customer);
            try {
                Thread.sleep(5000); // 5 seconds interval
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(e);
            }
        }
    }
}
