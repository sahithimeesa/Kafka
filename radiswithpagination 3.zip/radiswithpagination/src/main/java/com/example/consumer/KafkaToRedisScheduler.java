package com.example.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class KafkaToRedisScheduler {

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    private static final String KAFKA_TOPIC = "customers-records";

    // Scheduled method to run every 5 seconds
    @Scheduled(fixedRate = 5000)
    public void fetchAndStore() {
        // Logic to fetch data from Kafka topic
        String message = fetchMessageFromKafka();
        if (message != null) {
            // Store the message in Redis with a unique key
            String redisKey = "customer:" + System.currentTimeMillis(); // Change key as needed
            redisTemplate.opsForValue().set(redisKey, message);
            System.out.println("Stored in Redis: " + message);
        } else {
            System.out.println("No new messages to fetch from Kafka.");
        }
    }

    private String fetchMessageFromKafka() {
        // Placeholder logic to simulate fetching a message from Kafka
        // You can replace this with actual Kafka consumer logic if needed
        return "Sample message from Kafka"; // Replace this with actual Kafka consumer logic
    }
}

