package com.example.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


import java.io.Serializable;
import java.time.ZonedDateTime;

@Entity
public class Customer implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private ZonedDateTime localdatetime;

    // Default constructor
    public Customer() {
    }

    // Parameterized constructor
    public Customer(int id, String name, ZonedDateTime localdatetime) {
        this.id = id;
        this.name = name;
        this.localdatetime = localdatetime;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ZonedDateTime getLocaldatetime() {
        return localdatetime;
    }

    public void setLocaldatetime(ZonedDateTime localdatetime) {
        this.localdatetime = localdatetime;
    }

    // toString method for easier logging and debugging
    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", localdatetime=" + localdatetime +
                '}';
    }
}
