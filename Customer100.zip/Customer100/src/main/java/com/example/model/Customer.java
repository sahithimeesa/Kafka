package com.example.model;

import lombok.Data;

import javax.persistence.Entity;

@Entity
@Data
public class Customer {
    private int id;
    private String name;
    private int Salary;

    public Customer(){

    }

    public Customer(int id, String name, int salary) {
        this.id = id;
        this.name = name;
        Salary = salary;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(double salary) {
        Salary = (int) salary;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", Salary=" + Salary +
                '}';
    }

}
