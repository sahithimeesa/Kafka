package com.example.service;

import com.example.ksql.DatabaseConnectionManager;
import com.example.model.Customer;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.confluent.ksql.api.client.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.lang.Integer.parseInt;

@Service
public class CustomerService {
    private static final String TOPIC = "Customer_Data";

    @Autowired
    private ObjectMapper objectMapper; // Autowire ObjectMapper

    @Autowired
    private DatabaseConnectionManager databaseConnectionManager;

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    // Method to send customers to Kafka
    public void sendCustomers() {
        for (int i = 1; i <= 100; i++) {
            Customer customer = new Customer();
            customer.setId(i);
            customer.setName("Customer" + i);
            customer.setSalary(50000 + i * 100); // Example salary

            // Send message to Kafka
            kafkaTemplate.send(TOPIC, String.valueOf(customer.getId()), customer);
            System.out.println("Sent message: " + customer);

            // Simulate some delay between sends
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException(e);
            }
        }
        System.out.println("All customers published to Kafka topic.");
    }

    // Method to schedule customer publishing
    public void schedulePublishCustomers() {
        System.out.println("Starting to publish customers...");

        List<Customer> customers = getAll();
        System.out.println("Number of customers fetched: " + customers.size());

        for (Customer customer : customers) {
            if (customer != null) {
                // Send customer to Kafka (adjust topic as needed)
                kafkaTemplate.send(TOPIC, String.valueOf(customer.getId()), customer);
                System.out.println(" Extract customer from  Kafka: " + customer);
            } else {
                System.err.println("Null customer, skipping cache.");
            }
        }

        System.out.println("All customers published to Kafka and extract it .");
    }

    // Method to fetch all customers from KSQL
    public List<Customer> getAll() {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM CUSTOMERS_TABLE EMIT CHANGES LIMIT 20;";

        try {
            List<Row> rows = databaseConnectionManager.getData(sql);
            System.out.println("Rows retrieved: " + rows.size());

            if (rows.isEmpty()) {
                System.err.println("No data retrieved from KSQL.");
                return customers;
            }

            // Print all rows with their data
            for (Row row : rows) {
                try {
                    // Print the entire row (for debugging purposes)
                    System.out.println("Row: " + row);

                    // Parse the values from the row and create a Customer object
                    Customer customer = new Customer();
                    customer.setId(Integer.parseInt(row.getString("ID")));  // Assuming "ID" is an integer column
                    customer.setName(row.getString("NAME"));  // Assuming "NAME" is a string column
                    customer.setSalary(Double.parseDouble(row.getString("SALARY")));  // Assuming "SALARY" is a string column

                    // Print the customer object
                    System.out.println("Customer: " + customer);

                    // Add the customer to the list
                    customers.add(customer);

                } catch (NumberFormatException e) {
                    // Handle number format exception for invalid ID or salary
                    System.err.println("Invalid number format for customer ID or salary.");
                }
            }

            // Print the number of customers fetched
            System.out.println("Number of customers fetched: " + customers.size());

        } catch (Exception e) {
            // Handle the exception (maybe log or rethrow)
            System.err.println("Error fetching data from KSQL: " + e.getMessage());
        }
        return customers;
    }
}