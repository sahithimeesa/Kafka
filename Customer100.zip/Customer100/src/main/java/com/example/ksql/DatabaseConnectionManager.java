package com.example.ksql;

import ch.qos.logback.core.model.processor.ProcessorException;

import io.confluent.ksql.api.client.BatchedQueryResult;
import io.confluent.ksql.api.client.Client;
import io.confluent.ksql.api.client.ClientOptions;
import io.confluent.ksql.api.client.Row;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;




@Service
public class DatabaseConnectionManager {
    Log logger = LogFactory.getLog(this.getClass());

    @Value("${KSQLDB_TIMEOUT_IN_SECONDS:100}")
    private int timeout;

    @Autowired
    private ClientOptions ksqlClientOptions;

    private DatabaseConnectionManager instance;
    private ClientOptions options;

    public DatabaseConnectionManager() {
    }

    public List<Row> getData(String sql) throws ProcessorException {
        Client client = Client.create(ksqlClientOptions);
        List<Row> rowsList = null;
        Map<String, Object> properties = Collections.singletonMap(
                "auto.offset.reset", "earliest");
        try {
            logger.info(sql);
            BatchedQueryResult result = client.executeQuery(sql);

            try {
                rowsList = result.get();  // Waits for the query result to complete
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
            return rowsList;
        } catch (Exception e) {
            logger.error(e, e);
            throw new ProcessorException();
        } finally {
            client.close();
        }
    }
}

